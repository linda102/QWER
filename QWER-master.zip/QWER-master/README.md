# QWER Kodi Addons Repository
Repozytorium wizarda dla programu KODI
plugin.program.QWERZ.zip (wersja 1.0.1)
# Zainstaluj z pliku zip poprzez źródło: https://meserak86.github.io/QWER/

Jakby ktoś chciał: https://kodihub.net (szybki darmowy hosting BUILDÓW Kodi do 300MB)
